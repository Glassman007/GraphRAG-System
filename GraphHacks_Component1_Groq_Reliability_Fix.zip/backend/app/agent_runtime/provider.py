"""Strict OpenAI-compatible chat-completions adapter: OpenAI, Groq, configured endpoint.

The agent only receives graph facts after the caller explicitly consents to transmission.
Provider responses are untrusted, validated in the harness, and never executed as code.
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

import httpx


class ProviderError(RuntimeError):
    pass


@dataclass(frozen=True)
class Completion:
    content: str
    calls: list[dict[str, Any]]
    tokens: int
    finish_reason: str = ""


class OpenAICompatibleProvider:
    def __init__(self, *, provider: str | None = None):
        name = (provider or os.getenv('GRAPH_HACKS_AGENT_PROVIDER') or 'groq').strip().lower()
        if name not in {'groq', 'openai', 'compatible'}:
            raise ProviderError('Agent provider must be groq, openai, or compatible')
        bases = {'groq': 'https://api.groq.com/openai/v1', 'openai': 'https://api.openai.com/v1'}
        models = {'groq': 'openai/gpt-oss-120b', 'openai': 'gpt-4.1-mini'}
        base = bases.get(name) or os.getenv('GRAPH_HACKS_AGENT_BASE_URL', '').strip().rstrip('/')
        parsed = urlparse(base)
        if not base or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path.endswith('/chat/completions'):
            raise ProviderError('Invalid provider base URL')
        if parsed.scheme != 'https' and not (parsed.scheme == 'http' and parsed.hostname in {'127.0.0.1', 'localhost'}):
            raise ProviderError('Provider endpoints must use HTTPS, except local loopback')
        if name != 'compatible' and base != bases[name]:
            raise ProviderError('Built-in provider endpoint cannot be overridden')
        env_key = {'groq':'GROQ_API_KEY', 'openai':'OPENAI_API_KEY','compatible':'GRAPH_HACKS_AGENT_API_KEY'}[name]
        self.api_key = os.getenv(env_key, '').strip()
        if name != 'compatible' and not self.api_key:
            raise ProviderError(f'{env_key} is missing; no model call was made')
        self.name = name
        self.base = base
        self.model = os.getenv('GRAPH_HACKS_AGENT_MODEL', models.get(name, '')).strip()
        if not self.model:
            raise ProviderError('Set GRAPH_HACKS_AGENT_MODEL')

    def complete(self, messages: list[dict[str, Any]], tools: list[dict[str, Any]], *,
                 remaining_seconds: float, max_output_tokens: int) -> Completion:
        if remaining_seconds <= 0:
            raise ProviderError('Agent deadline reached')
        headers = {'Content-Type': 'application/json'}
        if self.api_key:
            headers['Authorization'] = 'Bearer ' + self.api_key
        payload: dict[str, Any] = {
            'model': self.model, 'messages': messages, 'temperature': 0,
            'max_completion_tokens': max_output_tokens,
        }
        if tools:
            payload['tools'] = tools
            payload['tool_choice'] = 'auto'
        elif self.name == 'groq':
            # Planning has no tool calls and must return parseable JSON.
            # Do not apply JSON mode to tool calls; those require function messages.
            payload['response_format'] = {'type': 'json_object'}
        if self.name == 'groq' and self.model in {'openai/gpt-oss-120b', 'openai/gpt-oss-20b'}:
            # GPT-OSS counts internal reasoning against output/rate budgets.
            payload['reasoning_effort'] = 'low'
            if tools:
                payload['parallel_tool_calls'] = False
        try:
            # Hard upper bound on a provider HTTP call. Credentials and raw responses are
            # intentionally excluded from exceptions and trace records.
            started = time.monotonic()
            with httpx.Client(timeout=min(max(0.5, remaining_seconds), 25.0), follow_redirects=False) as client:
                for attempt in range(2):
                    response = client.post(f'{self.base}/chat/completions', json=payload, headers=headers)
                    if response.status_code != 429:
                        break
                    # Groq documents a Retry-After header in seconds on 429.
                    # Retry at most once and only if this run has enough time left.
                    retry_header = response.headers.get('retry-after', '')
                    try:
                        delay = float(retry_header)
                    except ValueError:
                        delay = -1.0
                    time_left = remaining_seconds - (time.monotonic() - started)
                    if attempt == 0 and 0 <= delay <= min(65.0, time_left - 3):
                        time.sleep(delay + 0.15)
                        continue
                    hint = f'; retry-after={retry_header}s' if retry_header else '; check Groq organization limits'
                    raise ProviderError(f'{self.name} rate limited (HTTP 429){hint}')
            if response.status_code != 200:
                raise ProviderError(f'{self.name} returned HTTP {response.status_code}')
            body = response.json()
            choice = body['choices'][0]
            message = choice['message']
            calls = []
            for call in message.get('tool_calls') or []:
                function = call.get('function') or {}
                calls.append({'id': str(call.get('id') or ''), 'name': str(function.get('name') or ''),
                              'arguments': str(function.get('arguments') or '{}')})
            return Completion(content=str(message.get('content') or ''), calls=calls,
                              tokens=int((body.get('usage') or {}).get('total_tokens') or 0),
                              finish_reason=str(choice.get('finish_reason') or ''))
        except ProviderError:
            raise
        except (httpx.RequestError, ValueError, KeyError, TypeError, IndexError) as exc:
            raise ProviderError(f'{self.name} request or response failed: {type(exc).__name__}') from None
